USE Library_Management_System;

SELECT * FROM tbl_library_branch;
Select * FROM tbl_book;
SELECT * FROM tbl_borrower;
SELECT * FROM tbl_publisher;
SELECT * FROM tbl_book_loans;
SELECT * FROM tbl_book_copies;
SELECT * FROM tbl_book_authors;



# 1. How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"? 
SELECT 
	 T3.library_branch_BranchName as Branch_name,
     T2.book_Title as Book_Name,
     T1.book_copies_No_Of_Copies as No_of_Copies
FROM tbl_book_copies AS T1
JOIN
    tbl_book AS T2 ON T1.book_copies_CopiesID = T2.book_BookID
JOIN
    tbl_library_branch AS T3 ON T1.book_copies_BranchID = T3.library_branch_BranchID
WHERE
    T2.book_Title LIKE 'The Lost Tribe' AND T3.library_branch_BranchName LIKE 'Sharpstown';
    


# 2. How many copies of the book titled "The Lost Tribe" are owned by each library branch?

SELECT 
    T3.library_branch_BranchName AS Branch_Name, 
    T2.book_Title as Book_name,
    T1.book_copies_No_Of_Copies AS Number_of_Copies
FROM 
    tbl_book_copies T1
JOIN 
    tbl_book T2 ON T1.book_copies_BookID = T2.book_BookID
JOIN 
    tbl_library_branch T3 ON T1.book_copies_BranchID = T3.library_branch_BranchID
WHERE 
    T2.book_Title = 'The Lost Tribe';



# 3. Retrieve the names of all borrowers who do not have any books checked out. 
SELECT 
	T1.borrower_BorrowerName as Borrower_name,
    T2.book_loans_CardNo as loans_card
FROM tbl_borrower AS T1
LEFT JOIN tbl_book_loans AS T2 ON T1.borrower_CardNo = T2.book_loans_CardNo
WHERE T2.book_loans_CardNo IS NULL;



# 4. For each book that is loaned out from the "Sharpstown" branch and whose 
   # DueDate is 2/3/18, retrieve the book title, the borrower's name, and the 
   # borrower's address. 
SELECT
    T1.book_Title,
    T3.borrower_BorrowerName as Borrower_name,
    T3.borrower_BorrowerAddress as Borrower_Address
FROM tbl_book AS T1
JOIN tbl_book_loans AS T2 
      ON T2.book_loans_BookID = T1.book_BookID
JOIN tbl_borrower AS T3 
      ON T2.book_loans_CardNo = T3.borrower_CardNo
JOIN tbl_library_branch AS T4 
      ON T2.book_loans_BranchID = T4.library_branch_BranchID
WHERE T4.library_branch_BranchName = 'Sharpstown' 
		AND T2.book_loans_BookID IS NOT NULL 
        AND T2.book_loans_DueDate = '2/3/18';



# 5. For each library branch, retrieve the branch name and the total number of books loaned out from that branch. 
SELECT
    T1.library_branch_BranchName,
    COUNT(T2.book_loans_LoansID) AS Total_Books_Loaned
FROM
    tbl_library_branch AS T1
JOIN
    tbl_book_loans AS T2 ON T1.library_branch_BranchID = T2.book_loans_BranchID
GROUP BY
    T1.library_branch_BranchName;
    
    
    
# 6. Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out. 
SELECT
    T1.borrower_BorrowerName as Borrower_name,
    T1.borrower_BorrowerAddress as Borrower_address,
    COUNT(T2.book_loans_LoansID) AS No_of_Books_Checked_Out
FROM tbl_borrower AS T1
JOIN
    tbl_book_loans AS T2 ON T1.borrower_CardNo = T2.book_loans_CardNo
GROUP BY T1.borrower_CardNo
HAVING COUNT(T2.book_loans_LoansID) > 5;



# 7. For each book authored by "Stephen King", retrieve the title and the number of 
    #copies owned by the library branch whose name is "Central". 
SELECT
    T2.book_authors_AuthorName as Author_name,
    T4.library_branch_BranchName as Library_Branch,
    T1.book_Title,
    T3.book_copies_No_Of_Copies
FROM tbl_book AS T1
JOIN
    tbl_book_authors AS T2 ON T1.book_BookID = T2.book_authors_BookID
JOIN
    tbl_book_copies AS T3 ON T1.book_BookID = T3.book_copies_BookID
JOIN
    tbl_library_branch AS T4 ON T3.book_copies_BranchID = T4.library_branch_BranchID
WHERE
    T2.book_authors_AuthorName = 'Stephen King' AND T4.library_branch_BranchName = 'Central';